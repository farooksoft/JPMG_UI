const concat = require('./index');
test('join Scooby and doo to be ScoobyDoo',()=>{
    expect(concat('scooby', 'doo')).toBe('scoobydoo');
});