const profile = {
    name: 'farooksoft',
    githubUrl:'https://github.com/farooksoft',
    twitterUrl:'https://twitter.com/farooksoft'
};

test('expects profile to be an object', ()=>{
    expect(typeof profile).toBe('object');
});