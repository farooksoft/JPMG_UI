// toEqual
// toBeNull
// toBeUndefined
// toBeDefined
// toMatch
// toContain

const data = {
    name : 'Scooby',
    lastName:'Doo'
};
test('Object Assignment', ()=>{
    expect(data).toEqual({name: 'Scooby', lastName:'Doo'});

});

test('null', ()=>{
    const n = null;
    expect(n).toBeNull();
    expect(n).toBeDefined();
    expect(n).not.toBeUndefined();
});


test('zero', ()=>{
    const zero = 0;
    expect(zero).not.toBeNull();
    expect(zero).toBeDefined();
    expect(zero).not.toBeUndefined();
});

const sum = 6+5;
test('six + Five', ()=>{
    expect(sum).toBeGreaterThan(10);
    expect(sum).toBeGreaterThanOrEqual(11);
    expect(sum).toBeLessThan(12);
    expect(sum).toBeLessThanOrEqual(11);
});

const languages = [
    'JavaScript', 'Java'
];

test('languagescontaines JavaScript ', ()=>{
    expect(languages).toContain('JavaScript');
});

test('g in Programmer', ()=>{
    expect('Programmer').toMatch(/g/);
});