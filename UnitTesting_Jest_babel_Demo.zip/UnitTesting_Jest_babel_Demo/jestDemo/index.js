function concat(x,y){
    return x+y;
}
module.exports = concat;