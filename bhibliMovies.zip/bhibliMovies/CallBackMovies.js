const request = require('request');
const fs = require('fs').promises;
const axios = require('axios')

async function saveMovies(){
    try{
        let response = await axios.get('https://ghibliapi.herokuapp.com/films');
        let movieList = '';
        response.data.forEach(movie => {
            movieList+=`${movie['title']}, ${movie['release_date']}\n`;
        });
        await fs.writeFile('asyncAwaitMovies.csv', movieList);
    }
   catch(error){
    consolr.error(`couldn'n save the data to file: ${error}`);
}
}
saveMovies();


// axios.get('https://ghibliapi.herokuapp.com/films')
// .then((response) =>{
//     console.log('successfully retrived out list of movies');
//     let movieList = '';
//     response.data.forEach(movie => {
//         movieList+=`${movie['title']}, ${movie['release_date']}\n`;
//     });
//     return fs.writeFile('PromiseMovies.csv', movieList);
    
// })
// .then(()=>{
//     console.log('saved out list of movies to PromiseMivies.csv file');
    
// })
// .catch((error)=>{
//     console.error(`couldn't save the data into file: ${error}`);
// });



// request('https://ghibliapi.herokuapp.com/films',(error, response, body) =>{
//     if(error){
//         console.error(`could not send the request to API: ${error.message}`);
//         return;
//     }
//     if(response.statusCode !=200){
//         console.error(`Expected status code is 200 : ${error.statusCode}`);
//         return;
//     }

//     console.log("Processing our list of movies");
//     movies = JSON.parse(body);
//     let movieList = '';

//     movies.forEach(movie => {
//         movieList += `${movie['title']}, ${movie['release_date']}\n`;
        
//     });

//     fs.writeFile('CallBackMovies.csv', movieList, (error)=>{
//         if(error){
//             console.error(`could not save the movie list to a file: ${error}`);
//             return;
//         }
//         console.log('saved our list of movies to CSV file');
        
//     })
    
// })

