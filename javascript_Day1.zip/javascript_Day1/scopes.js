var firstName = "Scooby";
var lastName = "doo";

function fullName(){
     var lastName = "Scrapy";
     function designation(){
         var role = "Mystry Solver";
         console.log("Designtion inside nested: " + firstName+ " "+ lastName+  " is "   + role);
         
     };
     designation();
    console.log("Full name from inside the functions " + firstName + " "+ lastName);
    
}
fullName();
console.log("Full name from outside the functions "+ firstName + " "+ lastName);
    
