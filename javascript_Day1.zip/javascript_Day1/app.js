// console.log("hello world");
// console.log('hello World');
// // alert("Hello Guys!!!")

// var data = 300;
// var name = "Thomas";
// var bool = true;
// console.log(data + " " + name + " " + bool);

// // diff bet var & let
// function varTest() {
//     let x = 1;
//     if (true) {
//         let x = 2;
//         console.log("inner: " + x);
//     }
//     console.log("outer: "+x);
// }
// varTest();

// function say(message){
//     console.log(message);
//     console.log("im done till here");
    
    
// }
// let result = say("hello guys, this is a demo on function");
// console.log("Result",result);

// function compare(a, b){
//     if(a > b){
//         return -1;
//     }else if(a < b){
//         return 1;
//     }
//     return ;
// }

// let sum = compare(100, 100);
// console.log("Addition",sum);

console.log(add(1, 2, 3, 4, 5, 6));
console.log(add(102, 345, 234));

function add(){
    let sum = 0;
    for (let i = 0; i < arguments.length; i++){
        sum += arguments[i];
    }
    return sum;
}



var num1 = 2;
console.log("value of number 1 is "+ num1 + ". (Global Scope)</br>" );

function parentFunction(){ // global Function
    var num2 = 4;
    console.log("value of number 1 is "+ num1 + ". (inside Global function)</br>" );
    console.log("value of number 1 is "+ num2 + ". (inside Global function)</br>" );
    childFunction();
    function childFunction(){ //nested function
        var num3 = 40;
        console.log("value of number 1 is "+ num1 + ". (inside child function)</br>" );
        console.log("value of number 1 is "+ num2 + ". (inside child function)</br>" );
        console.log("value of number 1 is "+ num3 + ". (inside child function)</br>" );
    }
}
parentFunction();

//arrow function
function arrow(str){
    return " hello" + str;
}
console.log(arrow("Hello guys, its a demo for Arrow"));

var arrowDemo = str => "hello" + str;
console.log("By the arrrow function itself");
console.log(arrowDemo("Arrow Demo in JavaScript"));






