//Default binding
// function foo(){
//     this.a = 'hello';
//     console.log(this);
    
// }

// foo();

//implicit Binding
// function bar(){
//     console.log(this);
// }

// var foo = {
//     a : 'foo',
//     b : bar,
// }
// foo.b();

//explicit Binding
// function bar(){
//     console.log(this);
// }

// var foo = {
//     a : 'foo',
// }

// bar.bind(foo)();
// bar.call(foo);
// bar.apply(foo);

//new binding
// function foo(){
//     this.a = 'a';
//     this.log = function(){
//         console.log(this);
        
//     }
// }
// var bar = new foo();
// bar.log();

//demo

let person = {
    firstName : 'Stuart',
    lastName : 'Little',
    greet : function(){
        console.log("hello world");
        
    },
    getFullName : function(){
        return this.firstName + ' ' + this.lastName;
    }
};
console.log(person.getFullName);
console.log(person.greet);

