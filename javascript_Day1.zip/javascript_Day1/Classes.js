class Person {
    name = 'Tom Jerry';
    getName() {
        return this.name;
    }
}
const person = new Person();
console.log(person.getName());
