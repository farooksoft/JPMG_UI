var days = ['sun', 'mon', 'tues','wed','thurs', 'fri', 'sat'];
var months = ['Jan', 'Feb', 'March', 'Apr', 'May', 'june', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
var date = new Date();
var currentDay = days[date.getDay()];
var currentMonth = months[date.getMonth()];
var currentDate = date.getDate();
var currentYear = date.getFullYear();
console.log(currentDay + ' '+ currentMonth+ ' '+ currentDate + ' '+ currentYear);

var hrs = date.getHours(), min = date.getMinutes();
var suffix = 'AM';

if(hrs >= 12){
    hrs -= 12;
    suffix = 'PM';
}
if(hrs < 10){
    hrs = '0' + hrs
}
if(min < 10){
    min = '0'+ min;
}
console.log(hrs + ' '+min + ' '+ suffix);


console.log(date.toDateString());
console.log(date.toTimeString());
console.log(date.toUTCString());


