let scores = new Array(10, 20, 2, 4, 3, 6, 5, 4);
let data = new Array('Hello World');

// let person = Array();
let person = ['adam', 'Olive', 'sturat'];
console.log(person[0]);

person[2] = 'stuart little';

// person.push('Popeye')
person.unshift('Scooby');

// const lastElement = person.pop();
// const firstElement = person.shift();
console.log(person+ ' '+ person.length);
console.log(person.indexOf('Olive'));


console.log(Array.isArray(person));


