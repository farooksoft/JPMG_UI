let person = {
    firstName : "Adam",
    lastName : "Smith",
    age : 25,
    greet : function(){
        console.log('mthod shorthad demo');        
    }
};
person.lastName = "Doe"

console.log(person.firstName);
console.log(person.lastName);

//array notation
console.log(person['firstName']);
console.log(person['lastName']);


//iterate the data with for-in

for(const key in person){
    console.log('keys of person '+key);
    
}

//methods
// person.greet = function(){
//     console.log("hello guys!!!");
// }
// person.greet();

// function greet(){
//     console.log('hello from jpmg');
// }
// person.greet = greet;

// person.greet();


//method shorthand
person.greet();

delete person.lastName;
console.log(person['lastName']);

console.log('firstName' in person);
console.log('age' in person);






