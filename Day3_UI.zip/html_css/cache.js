setTimeout(function(){
    document.getElementById('clock').value = new Date();
}, 1000);