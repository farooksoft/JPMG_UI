j =0;
while (j < 200000){
    postMessage("web Worker Counter:" +j);
    j++;
}