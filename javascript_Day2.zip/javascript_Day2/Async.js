// console.log("Hi");

// setTimeout(function(){
//     console.log("Good Afternoon");
// }, 5000);

// console.log('Hi again');

// for(var i=1; i<=3;i++){
//     setTimeout(function(){
//         console.log(i + "Seconds elapsed");
        
//     }, i*2000);
// }

// var promise =  new Promise(function(resolve, reject){
//     setTimeout(function(){
//         resolve('hello guys!!!');
//     }, 2000);
// });

// promise.then(function(value){
//     console.log(value);
    
// });
// console.log(promise);

// async function myfunc(){
//     return "Hello Guys!!!"
// }
// myfunc().then(data => console.log(data))


// function resolveAfter25Sec(){
//     return new Promise(resolve => {
//         setTimeout(() => {
//             resolve('resolved');
//         }, 2000);
//     });
// }
// async function asyncCall(){
//     console.log('calling');
//     const result = await resolveAfter25Sec();
//     console.log(result);
    
    
// }
// asyncCall();


//thenable
// async function f2(){
//     const thenable ={
//         then: function(resolve, _reject){
//             resolve('resolved!!!!');
//         }
//     };
//     console.log(await thenable);
    
// }
// f2();

//promise rejection

async function f3(){
    try{
        var z = await Promise.reject(30);
    }catch(e){
        console.log(e);
        
    }
}
f3();