// let str = `Template literal demo  employee\`s usage of backslash`;

// console.log(str);
// console.log(str.length);
// console.log(typeof str);

function format(literals, ...substitutions){
    let result = ' ';

    for(let i = 0; i< substitutions.length; i++){
        result += literals[i];
        result += substitutions[i];
    }

    result += literals[literals.length -1];
return result;
}

let quatity = 8;
priceEach = 5.50;
result = format `${quatity} items cost $${(quatity * priceEach).toFixed(2)}.`;
console.log(result);

var firstName = 'John';
var lastName = 'jacob';

let text = `Welcome ${firstName}, ${lastName}!!!`;
console.log(text);

let post = {
    title: 'java script template literals',
    excerpt : 'introduction to javascript temlate literals in ES6',
    body: 'Content of the post will be here...',
    tags : ['es6', 'template literals', 'javascript']
};

let {title, excerpt, body, tags} = post;

var postHTML = `
    <article>
    <header>    <h1> ${title} </h1> </header>
    <section> <div> ${excerpt}</div> <div> ${body} </div> </section>
    <footer>
    <ul>
    ${tags.map(tag =>`<li> ${tags}</li>`).join('\n    ')}
    </ul>
    </footer>
`;

console.log(postHTML);
