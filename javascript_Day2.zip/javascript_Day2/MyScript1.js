var userName = "Scooby";

(function(name){
    function display(name){
        alert("MyScript1.js " +name);
    }
    
    display(userName);
})(userName)
