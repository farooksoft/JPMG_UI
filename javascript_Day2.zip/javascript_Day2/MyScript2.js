var userName = "Scrappy";

(function (name){
    function display(name){
        alert("MyScript2.js " +name);
    }
    
    display(userName);
})(userName)
