const Animal = {
    // constructor(name){
    //     this.name = name;
    // }
    speak(){
        console.log(this.name + ' makes a noise.');
        
    }
};

class Dog {
    constructor(name){
        this.name = name;
    }
}

Object.setPrototypeOf(Dog.prototype, Animal);
let dog = new Dog('Tuffy');
dog.speak();