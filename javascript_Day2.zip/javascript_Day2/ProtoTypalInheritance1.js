// var price = 10.59;
// justANumber = 43;
// original_toString = Number.prototype.toString;

// console.log('Proce before toString() update: '+price.toString());

// Number.prototype.toString = function(radix){
//     return '$ '+original_toString.call(this, radix);
// };

// console.log('Price after the toString() update: ' +price.toString());
// console.log('oh oh.just a number '+ justANumber.toString()+ ' ?! ');

function Vehicle(name){
    this.name = name;
}

Vehicle.prototype.start = function(){
    return "Engine of "+ this.name + " Starting ...";
};

function Car(name){
    Vehicle.call(this,name);
}

Car.prototype = Object.create(Vehicle.prototype);
Car.prototype.start = function(){
    console.log("Gidday!! " + Vehicle.prototype.start.call(this));
    
};

function Van(name){
    Vehicle.call(this, name);
}

Van.prototype = Object.create(Vehicle.prototype);

var c1 = new Car("Santro");
var c2 = new Car("Tata Punch");
var v1 = new Van ("Mazda");

c1.start();
c2.start();

console.log(v1.start());

Van.prototype.start = function(){
    console.log("Hellow!!!! " +Vehicle.prototype.start.call(this) );
    
};
v1.start();


