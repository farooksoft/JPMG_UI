function sum(x, y, z){
    return x+ y + z;
}
const num = [3,6,8];
console.log(sum.apply(null, num));

//spread syntax
console.log(sum(...num));

let arr = [1,3,4,5,6];
let arr1 = [5,4,3,2,1];

arr = [...arr, ...arr1];
console.log(arr);

let arr3 = [...arr1];
console.log(arr1);

arr1.push('d');

console.log('Arraye 3: '+arr3);

