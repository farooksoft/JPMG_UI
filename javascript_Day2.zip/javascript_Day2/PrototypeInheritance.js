//Parent
function Vehicle (name){
    this.name = name;
}

//parent mtd
Vehicle.prototype.start = function(){
    return "Engine of "+this.name + " starting";
};

//child
function Car(name){
    Vehicle.call(this,name);
}
//child extends parent
Car.prototype = Object.create(Vehicle.prototype);

//child mtd
Car.prototype.start = function(){
    console.log("Gidday!! " + Vehicle.prototype.start.call(this));
    
};

//instance of child
var c1 = new Car("Toyota");
//accessig the child mtd whicn internally access parent mtd
c1.start();