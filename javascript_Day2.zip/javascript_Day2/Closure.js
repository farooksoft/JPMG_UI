function OuterFunction(){
    var outerVariable = 1;
    function InnerFunction(){
        console.log(outerVariable);
    }
    return InnerFunction;
}
var outerfun = OuterFunction();
outerfun();