// var promise = new Promise(function(resolve, reject){
//     var firstString = "I am Fine";
//     var secondString = "I am sad";
//     if(firstString === secondString){
//         resolve();
//     }else{
//         reject();
//     }
// });
// promise.then(function(){
//     console.log("Yeah, iam in resolve state conditions");
    
// }).catch(function(){
//     console.log('OOPS im in rejected state');
    
// })

var promise = new Promise(function(resolve, reject){
    // reject("iam executing from then function because of successful functionality");
    throw new Error("iam executing from then function because of successful functionality")

})
promise.then(function(gainMessage){
    console.log(gainMessage);
    
}, function(errMsg){
    console.log(errMsg);
    
})