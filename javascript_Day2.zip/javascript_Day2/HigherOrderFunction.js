//forEach
var Array1 = [112, 245, 141, 4, 901];
var data = Array1.forEach(function(element){
    console.log(element);
    
})
console.log(data);

// Map
var Array2 = [123,432,544,777,334,864];
var data1 = Array2.map(function(element){
    return element +4;
})
console.log(data1);

//reduce
var Array3 = [432,678,897,976,555,332];
var data2 = Array3.reduce(function(a, b){
    return a + b;
},2)
console.log(data2);

//filters
var Array4 = [456,555,777,8,999,32];
var data3 = Array4.filter(function(element){
    return element > 500;
})
console.log(data3);

