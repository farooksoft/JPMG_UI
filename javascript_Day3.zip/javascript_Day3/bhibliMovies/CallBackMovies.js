const request = require('request');
const fs = require('fs');

request('https://ghibliapi.herokuapp.com/films',(error, response, body) =>{
    if(error){
        console.error(`could not send the request to API: ${error.message}`);
        return;
    }
    if(response.statusCode !=200){
        console.error(`Expected status code is 200 : ${error.statusCode}`);
        return;
    }

    console.log("Processing our list of movies");
    movies = JSON.parse(body);
    let movieList = '';

    movies.forEach(movie => {
        movieList += `${movie['title']}, ${movie['release_date']}\n`;
        
    });

    fs.writeFile('CallBackMovies.csv', movieList, (error)=>{
        if(error){
            console.error(`could not save the movie list to a file: ${error}`);
            return;
        }
        console.log('saved our list of movies to CSV file');
        
    })
    
})