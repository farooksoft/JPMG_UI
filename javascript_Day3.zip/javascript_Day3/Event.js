const EventEmitter = require("events")
const emitter = new EventEmitter()
var n = 0;
emitter.once('increment_number', function(){
    console.log(++n);
})
emitter.emit('increment_number');
emitter.emit('increment_number');
emitter.emit('increment_number');
emitter.emit('increment_number');
emitter.emit('increment_number');
emitter.emit('increment_number');
// })
// emitter.once('messageLogged',
// function(){
//     console.log("Listening to the event messageLogged");
    
// })
// emitter.emit('messageLogged');

