const http = require('http');
const server = http.createServer(function(req,res){
    if(req.url === '/'){
        res.writeHead(200,{'content-type':'text/html'});
        res.write('<html><body><p>This is home page.</p></body></html>');
        res.end();
    }else if(req.url === '/contact'){
        res.writeHead(200,{'content-type':'text/html'});
        res.write('<html><body><p>This is contact page.</p></body></html>');
        res.end();
    }else if(req.url === '/admin'){
        res.writeHead(200,{'content-type':'text/html'});
        res.write('<html><body><p>This is admin page.</p></body></html>');
        res.end();
    }else if(req.url === '/career'){
        res.writeHead(200,{'content-type':'text/html'});
        res.write('<html><body><p>This is career page.</p></body></html>');
        res.end();
    }else{
        res.end('Invalid request');
    }
})




// const server = http.createServer((req,res)=>{
//     if(req.url ==='/now'){
//         res.writeHead(200, {'content-type': 'application/json'});
//         res.write(JSON.stringify({now: new Date()}));
//         res.end();
//     }else{
//         res.end('Invalid Request');
//     }
// });
// const server = http.createServer((req,res) => {
//     if(req.url === '/'){
//         res.write('<h1>Hello, Node Js!!!</h1>')
//     }
//     res.end();
// })

server.listen(1234);
console.log("The http server is up and running....");
