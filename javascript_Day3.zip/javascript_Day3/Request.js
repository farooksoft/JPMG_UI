const request = require('request');
const fs = require('fs');

request('https://ghibliapi.herokuapp.com/people',(error, response, body) =>{
    if(error){
        console.error(`could not send the request to API: ${error.message}`);
        return;
    }
    if(response.statusCode !=200){
        console.error(`Expected status code is 200 : ${error.statusCode}`);
        return;
    }

    console.log("Processing our list of mivies");
    movies = JSON.parse(body);
    movies.forEach(movie => {
        console.log(`${movie['title']}, ${movie['release_date']}`);
        
    });
    
})