var filesystem = require("fs");
console.log("example to write the content in write mode");
filesystem.open('D:\\DEEemo.txt', 'w+', function(error, callback){
    if(error){
        return console.error(error);
    }
    console.log("file has been opened successfully");
    
})



// var fileContent = filesystem.readFileSync('D:\\demo.txt', 'UTF-8');
// console.log(fileContent);



// filesystem.readFile('D:\\demo.txt', 'utf-8', function(error, data){
//     if(error) throw error;
//     console.log(data);    
// });


// var filesystem = require("fs");
// var dir = "D:\\demo.txt";
// filesystem.open(dir, "w+", function(error, data){
//     if(error){
//         console.error("the error is"+ error.message);
//     }else{
//         console.log("The respiective file is opened at : "+dir);
        
//     }
// });